import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C6NReJQ8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var projects = [
	{
		name: "NANOBIR",
		summary: "The newest repository. A TypeScript app, last pushed in October 2026.",
		language: "TypeScript",
		stars: 0,
		pushed: "Oct 2026",
		github: "https://github.com/saberssr114/NANOBIR"
	},
	{
		name: "Nexus-VPN",
		summary: "NexusVPN Desktop. A Windows shell for a VPN dashboard. It does not open the tunnel — .ovpn files go to a separate OpenVPN client.",
		language: "JavaScript",
		stars: 0,
		pushed: "Oct 2026",
		github: "https://github.com/saberssr114/Nexus-VPN",
		live: "https://saberssr114.github.io/Nexus-VPN/"
	},
	{
		name: "g",
		summary: "A one-page poster. The line on it is Keep Moving Forward.",
		language: "HTML",
		stars: 0,
		pushed: "Aug 2026",
		github: "https://github.com/saberssr114/g",
		live: "https://saberssr114.github.io/g/indox.html"
	},
	{
		name: "image",
		summary: "A single HTML page, made the same week as the poster.",
		language: "HTML",
		stars: 0,
		pushed: "Aug 2026",
		github: "https://github.com/saberssr114/image",
		live: "https://saberssr114.github.io/image/indox.html"
	},
	{
		name: "catwheel",
		summary: "A small TypeScript app. One star on GitHub.",
		language: "TypeScript",
		stars: 1,
		pushed: "Aug 2026",
		github: "https://github.com/saberssr114/catwheel"
	},
	{
		name: "spinwheel",
		summary: "TypeScript, same season and same toolchain as catwheel.",
		language: "TypeScript",
		stars: 0,
		pushed: "Aug 2026",
		github: "https://github.com/saberssr114/spinwheel"
	},
	{
		name: "help-bot-telegram",
		summary: "A Python Telegram bot. Send a link and it returns the video, the images, and the text of the post.",
		language: "Python",
		stars: 1,
		pushed: "Aug 2026",
		github: "https://github.com/saberssr114/help-bot-telegram"
	},
	{
		name: "NANOBIV",
		summary: "NANOBI Media Vault. A dark shelf in the browser for saved media.",
		language: "HTML",
		stars: 0,
		pushed: "Aug 2026",
		github: "https://github.com/saberssr114/NANOBIV",
		live: "https://saberssr114.github.io/NANOBIV/NANOBI.html"
	},
	{
		name: "NANOBIQ",
		summary: "Another NANOBI page, kept as one HTML file.",
		language: "HTML",
		stars: 0,
		pushed: "Aug 2026",
		github: "https://github.com/saberssr114/NANOBIQ",
		live: "https://saberssr114.github.io/NANOBIQ/NANOBI.html"
	},
	{
		name: "NANOBIBOT",
		summary: "The Telegram media bot again, in its own repository.",
		language: "Python",
		stars: 0,
		pushed: "Aug 2026",
		github: "https://github.com/saberssr114/NANOBIBOT"
	},
	{
		name: "nanoBI",
		summary: "NANOBI Games. A page of latest game releases.",
		language: "HTML",
		stars: 0,
		pushed: "Jul 2026",
		github: "https://github.com/saberssr114/nanoBI",
		live: "https://saberssr114.github.io/nanoBI/nanobi.html"
	},
	{
		name: "Scan-Cat",
		summary: "Scan Cat. A page titled for virus and threat analysis.",
		language: "JavaScript",
		stars: 0,
		pushed: "Apr 2026",
		github: "https://github.com/saberssr114/Scan-Cat",
		live: "https://saberssr114.github.io/Scan-Cat/"
	},
	{
		name: "Klembre",
		summary: "An AI chat with Ask, Edit, and Review. There is a white cat in the files.",
		language: "JavaScript",
		stars: 0,
		pushed: "Mar 2026",
		github: "https://github.com/saberssr114/Klembre",
		live: "https://saberssr114.github.io/Klembre/ai-chat.html"
	},
	{
		name: "welcome-to-SKIRO",
		summary: "The welcome repository. The only description on it is HI WELCOME.",
		language: null,
		stars: 1,
		pushed: "Mar 2026",
		github: "https://github.com/saberssr114/welcome-to-SKIRO"
	},
	{
		name: "weather",
		summary: "PURE weather, opened on Cairo.",
		language: "JavaScript",
		stars: 0,
		pushed: "Mar 2026",
		github: "https://github.com/saberssr114/weather",
		live: "https://saberssr114.github.io/weather/"
	},
	{
		name: "PURE-weather",
		summary: "A smaller second pass at PURE weather. Same city.",
		language: "JavaScript",
		stars: 0,
		pushed: "Mar 2026",
		github: "https://github.com/saberssr114/PURE-weather",
		live: "https://saberssr114.github.io/PURE-weather/"
	},
	{
		name: "Live-weather",
		summary: "The name is reserved. The repository is still empty.",
		language: null,
		stars: 0,
		pushed: "Mar 2026",
		github: "https://github.com/saberssr114/Live-weather"
	},
	{
		name: "LeedGe",
		summary: "A landing page with a moving gradient, a home screen, and a login.",
		language: "HTML",
		stars: 0,
		pushed: "Mar 2026",
		github: "https://github.com/saberssr114/LeedGe",
		live: "https://saberssr114.github.io/LeedGe/home.html"
	},
	{
		name: "LECKD",
		summary: "A short welcome page.",
		language: "HTML",
		stars: 0,
		pushed: "Mar 2026",
		github: "https://github.com/saberssr114/LECKD",
		live: "https://saberssr114.github.io/LECKD/"
	},
	{
		name: "duck-chat",
		summary: "An inbox in three files: messages, profile, and settings.",
		language: "HTML",
		stars: 0,
		pushed: "Mar 2026",
		github: "https://github.com/saberssr114/duck-chat",
		live: "https://saberssr114.github.io/duck-chat/indox.html"
	},
	{
		name: "duckchat",
		summary: "MovBunsh. Login, a films page, and the inbox, with its own background.",
		language: "HTML",
		stars: 0,
		pushed: "Mar 2026",
		github: "https://github.com/saberssr114/duckchat",
		live: "https://saberssr114.github.io/duckchat/indox.html"
	},
	{
		name: "windows-11",
		summary: "Windows 11 Web Edition. A desk in the browser, not an installer.",
		language: "JavaScript",
		stars: 0,
		pushed: "Mar 2026",
		github: "https://github.com/saberssr114/windows-11",
		live: "https://saberssr114.github.io/windows-11/"
	},
	{
		name: "KAIZEN",
		summary: "The artist site. Video editor and designer — the line on it is Forging Reality From Pixels.",
		language: "CSS",
		stars: 0,
		pushed: "Jan 2026",
		github: "https://github.com/saberssr114/KAIZEN",
		live: "https://saberssr114.github.io/KAIZEN/"
	},
	{
		name: "-CINMEMAX-",
		summary: "CINEMAX. A movie page for films and shows.",
		language: "HTML",
		stars: 0,
		pushed: "Jan 2026",
		github: "https://github.com/saberssr114/-CINMEMAX-",
		live: "https://saberssr114.github.io/-CINMEMAX-/"
	},
	{
		name: "CINMEMAX-FREEDOME",
		summary: "The CINEMAX movie page, saved under a second name.",
		language: "HTML",
		stars: 0,
		pushed: "Jan 2026",
		github: "https://github.com/saberssr114/CINMEMAX-FREEDOME",
		live: "https://saberssr114.github.io/CINMEMAX-FREEDOME/"
	},
	{
		name: "CINMEMAX-FREEDOM",
		summary: "A third take on the CINEMAX movie page.",
		language: "HTML",
		stars: 0,
		pushed: "Jan 2026",
		github: "https://github.com/saberssr114/CINMEMAX-FREEDOM",
		live: "https://saberssr114.github.io/CINMEMAX-FREEDOM/"
	}
];
var FILTERS = [
	"All",
	"TypeScript",
	"JavaScript",
	"Python",
	"HTML",
	"CSS",
	"Other"
];
function Home() {
	const [query, setQuery] = (0, import_react.useState)("");
	const [filter, setFilter] = (0, import_react.useState)("All");
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			if (event.key !== "/" || event.metaKey || event.ctrlKey || event.altKey) return;
			const tag = event.target?.tagName;
			if (tag === "INPUT" || tag === "TEXTAREA") return;
			event.preventDefault();
			document.getElementById("project-search")?.focus();
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	const visible = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		return projects.filter((project) => {
			const lang = project.language ?? "Other";
			if (filter !== "All" && lang !== filter) return false;
			if (!q) return true;
			return project.name.toLowerCase().includes(q) || project.summary.toLowerCase().includes(q) || lang.toLowerCase().includes(q);
		});
	}, [filter, query]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-paper text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#content",
				className: "sr-only focus:not-sr-only focus:absolute focus:top-3 focus:left-3 focus:z-50 focus:bg-ink focus:px-3 focus:py-2 focus:text-paper",
				children: "Skip to content"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "rise sticky top-0 z-40 border-b border-line bg-paper/90 backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-2xl items-center justify-between gap-4 px-5 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "#top",
						className: "text-link flex min-h-11 items-center hover:text-bronze",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-medium tracking-wide",
							children: "SKIRO"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "flex items-center gap-1 text-sm",
						"aria-label": "Page",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#work",
								className: "nav-link inline-flex min-h-11 items-center px-2 hover:text-bronze",
								children: "Work"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#studio",
								className: "nav-link inline-flex min-h-11 items-center px-2 hover:text-bronze",
								children: "Studio"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#contact",
								className: "nav-link inline-flex min-h-11 items-center px-2 hover:text-bronze",
								children: "Contact"
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				id: "content",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					id: "top",
					className: "mx-auto max-w-2xl px-5 pt-16 pb-4 sm:pt-24",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
						className: "mark-in mx-auto w-full max-w-sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/logo.png",
							alt: "SKIRO monogram, a bronze mark on black",
							width: 379,
							height: 375,
							className: "h-auto w-full bg-mark"
						})
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "mx-auto max-w-2xl px-5 pt-12 pb-24",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "rise d1 text-xs font-medium tracking-widest text-bronze uppercase",
							children: "Studio index"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "rise d2 mt-4 text-4xl font-medium tracking-tight sm:text-5xl",
							children: "SKIRO"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "rise d3 mt-3 text-2xl leading-snug italic",
							children: "good time, good life."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "rise d4 mt-6 max-w-prose text-base leading-relaxed text-muted",
							children: [
								"Visual artist, video editor, and the name on ",
								projects.length,
								" public repositories. Kaizen is the picture work. This page is the software — the whole list, newest first, with nothing left in a drawer."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "rise d5 mt-6 flex flex-wrap gap-x-5 gap-y-1 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									className: "text-link inline-flex min-h-11 items-center underline decoration-line underline-offset-4 hover:text-bronze hover:decoration-bronze",
									href: "https://github.com/saberssr114",
									target: "_blank",
									rel: "noreferrer",
									children: "GitHub"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									className: "text-link inline-flex min-h-11 items-center underline decoration-line underline-offset-4 hover:text-bronze hover:decoration-bronze",
									href: "https://x.com/sshroud883",
									target: "_blank",
									rel: "noreferrer",
									children: "X"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									className: "text-link inline-flex min-h-11 items-center underline decoration-line underline-offset-4 hover:text-bronze hover:decoration-bronze",
									href: "https://saberssr114.github.io/KAIZEN/",
									target: "_blank",
									rel: "noreferrer",
									children: "Kaizen"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							id: "work",
							className: "rise d6 mt-20",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
									className: "text-3xl font-medium tracking-tight",
									children: ["The archive, ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "italic",
										children: "newest first."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-3 max-w-prose text-base leading-relaxed text-muted",
									children: [projects.length, " repositories. Live opens the GitHub Pages build when one exists. Code opens the repository."]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-8",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										htmlFor: "project-search",
										className: "text-xs tracking-widest text-bronze uppercase",
										children: "Search"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "project-search",
										value: query,
										onChange: (event) => setQuery(event.target.value),
										placeholder: "Name, language, or a word from the note",
										className: "mt-2 w-full border-b border-line bg-transparent py-3 text-base text-ink outline-none transition-colors duration-200 placeholder:text-muted focus:border-bronze"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-4 flex flex-wrap gap-1",
									role: "group",
									"aria-label": "Filter by language",
									children: FILTERS.map((item) => {
										const active = item === filter;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											"aria-pressed": active,
											onClick: () => setFilter(item),
											className: "min-h-11 px-3 text-sm underline-offset-4 transition-colors duration-200 " + (active ? "text-ink underline decoration-bronze" : "text-muted hover:text-ink"),
											children: item
										}, item);
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-6 text-sm text-muted",
									children: [
										visible.length,
										" ",
										visible.length === 1 ? "project" : "projects"
									]
								}),
								visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-8 border-t border-line py-10",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-base",
										children: "Nothing in the archive matches."
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "mt-3 inline-flex min-h-11 items-center text-sm underline decoration-bronze underline-offset-4",
										onClick: () => {
											setQuery("");
											setFilter("All");
										},
										children: "Show every project"
									})]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
									className: "mt-2",
									children: visible.map((project, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "project-row rise grid grid-cols-[2.25rem_1fr] gap-x-3 border-t border-line py-6 sm:grid-cols-[2.25rem_1fr_7.5rem] sm:gap-x-6",
										style: { animationDelay: `${Math.min(index, 12) * 45}ms` },
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "pt-1 text-sm text-muted tabular-nums",
												children: String(index + 1).padStart(2, "0")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "min-w-0",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
														className: "text-xl font-medium tracking-tight",
														children: project.name
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "mt-2 max-w-prose text-sm leading-relaxed text-muted",
														children: project.summary
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
														className: "mt-3 text-sm text-muted sm:hidden",
														children: [
															project.language ?? "Other",
															" · ",
															project.pushed,
															project.stars > 0 ? ` · ${project.stars} star` : ""
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
														className: "mt-3 flex flex-wrap gap-x-5",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
															href: project.github,
															target: "_blank",
															rel: "noreferrer",
															className: "text-link inline-flex min-h-11 items-center text-sm underline decoration-line underline-offset-4 hover:text-bronze hover:decoration-bronze",
															children: "Code"
														}), project.live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
															href: project.live,
															target: "_blank",
															rel: "noreferrer",
															className: "text-link inline-flex min-h-11 items-center text-sm underline decoration-line underline-offset-4 hover:text-bronze hover:decoration-bronze",
															children: "Live"
														}) : null]
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "hidden text-right text-sm text-muted sm:block",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: project.language ?? "Other" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "mt-1",
														children: project.pushed
													}),
													project.stars > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
														className: "mt-1",
														children: [project.stars, " star"]
													}) : null
												]
											})
										]
									}, project.github))
								}, `${filter}:${query}`)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							id: "studio",
							className: "rise mt-20 border-t border-line pt-12",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
									className: "text-3xl font-medium tracking-tight",
									children: ["Studio, ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "italic",
										children: "in two halves."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-6 max-w-prose space-y-4 text-base leading-relaxed",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The GitHub profile is SKIRO. The bio under the name is the same line as the one above: good time, good life. Publishing there started in 2025." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-muted",
										children: "Kaizen is the artist half — visual work, video editing, design. Its own line is Forging Reality From Pixels. The repositories below that are tools, pages, bots, and experiments, listed here without dressing them up as more than they are."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-6",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "https://saberssr114.github.io/KAIZEN/",
										target: "_blank",
										rel: "noreferrer",
										className: "text-link inline-flex min-h-11 items-center text-sm underline decoration-bronze underline-offset-4 hover:text-bronze",
										children: "Open Kaizen"
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							id: "contact",
							className: "rise mt-20 border-t border-line pt-12",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "text-3xl font-medium tracking-tight",
								children: ["Contact, ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "italic",
									children: "three doors."
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "mt-6 divide-y divide-line border-y border-line",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: "https://github.com/saberssr114",
										target: "_blank",
										rel: "noreferrer",
										className: "door flex min-h-14 items-baseline justify-between gap-4 py-3 hover:text-bronze",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-lg",
											children: "GitHub"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm text-muted",
											children: "saberssr114"
										})]
									}) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: "https://x.com/sshroud883",
										target: "_blank",
										rel: "noreferrer",
										className: "door flex min-h-14 items-baseline justify-between gap-4 py-3 hover:text-bronze",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-lg",
											children: "X"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm text-muted",
											children: "@sshroud883"
										})]
									}) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: "https://saberssr114.github.io/KAIZEN/",
										target: "_blank",
										rel: "noreferrer",
										className: "door flex min-h-14 items-baseline justify-between gap-4 py-3 hover:text-bronze",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-lg",
											children: "Kaizen"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm text-muted",
											children: "Artist site"
										})]
									}) })
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
							className: "rise mt-16 flex flex-wrap items-baseline justify-between gap-3 border-t border-line pt-6 text-sm text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "© 2026 SKIRO" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#top",
								className: "text-link inline-flex min-h-11 items-center hover:text-bronze",
								children: "Back to the mark"
							})]
						})
					]
				})]
			})
		]
	});
}
//#endregion
export { Home as component };
