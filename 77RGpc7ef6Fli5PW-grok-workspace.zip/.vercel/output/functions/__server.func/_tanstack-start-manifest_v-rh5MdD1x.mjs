//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-rh5MdD1x.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DK_qyeKJ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DK_qyeKJ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-B-MErC-5.js"]
	}
} });
//#endregion
export { tsrStartManifest };
