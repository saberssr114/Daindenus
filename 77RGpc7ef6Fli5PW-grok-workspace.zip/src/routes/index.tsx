import { useEffect, useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { projects } from "@/data/projects";

export const Route = createFileRoute("/")({ component: Home });

const FILTERS = ["All", "TypeScript", "JavaScript", "Python", "HTML", "CSS", "Other"] as const;
type Filter = (typeof FILTERS)[number];

function Home() {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<Filter>("All");

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key !== "/" || event.metaKey || event.ctrlKey || event.altKey) return;
      const tag = (event.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      event.preventDefault();
      document.getElementById("project-search")?.focus();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return projects.filter((project) => {
      const lang = project.language ?? "Other";
      if (filter !== "All" && lang !== filter) return false;
      if (!q) return true;
      return (
        project.name.toLowerCase().includes(q) ||
        project.summary.toLowerCase().includes(q) ||
        lang.toLowerCase().includes(q)
      );
    });
  }, [filter, query]);

  return (
    <div className="min-h-screen bg-paper text-ink">
      <a
        href="#content"
        className="sr-only focus:not-sr-only focus:absolute focus:top-3 focus:left-3 focus:z-50 focus:bg-ink focus:px-3 focus:py-2 focus:text-paper"
      >
        Skip to content
      </a>

      <header className="rise sticky top-0 z-40 border-b border-line bg-paper/90 backdrop-blur-sm">
        <div className="mx-auto flex max-w-2xl items-center justify-between gap-4 px-5 py-3">
          <a href="#top" className="text-link flex min-h-11 items-center hover:text-bronze">
            <span className="text-sm font-medium tracking-wide">SKIRO</span>
          </a>
          <nav className="flex items-center gap-1 text-sm" aria-label="Page">
            <a href="#work" className="nav-link inline-flex min-h-11 items-center px-2 hover:text-bronze">
              Work
            </a>
            <a href="#studio" className="nav-link inline-flex min-h-11 items-center px-2 hover:text-bronze">
              Studio
            </a>
            <a href="#contact" className="nav-link inline-flex min-h-11 items-center px-2 hover:text-bronze">
              Contact
            </a>
          </nav>
        </div>
      </header>

      <main id="content">
        <div id="top" className="mx-auto max-w-2xl px-5 pt-16 pb-4 sm:pt-24">
          <figure className="mark-in mx-auto w-full max-w-sm">
            <img
              src="/logo.png"
              alt="SKIRO monogram, a bronze mark on black"
              width={379}
              height={375}
              className="h-auto w-full bg-mark"
            />
          </figure>
        </div>

        <article className="mx-auto max-w-2xl px-5 pt-12 pb-24">
          <p className="rise d1 text-xs font-medium tracking-widest text-bronze uppercase">Studio index</p>
          <h1 className="rise d2 mt-4 text-4xl font-medium tracking-tight sm:text-5xl">SKIRO</h1>
          <p className="rise d3 mt-3 text-2xl leading-snug italic">good time, good life.</p>
          <p className="rise d4 mt-6 max-w-prose text-base leading-relaxed text-muted">
            Visual artist, video editor, and the name on {projects.length} public repositories.
            Kaizen is the picture work. This page is the software — the whole list, newest first,
            with nothing left in a drawer.
          </p>
          <p className="rise d5 mt-6 flex flex-wrap gap-x-5 gap-y-1 text-sm">
            <a
              className="text-link inline-flex min-h-11 items-center underline decoration-line underline-offset-4 hover:text-bronze hover:decoration-bronze"
              href="https://github.com/saberssr114"
              target="_blank"
              rel="noreferrer"
            >
              GitHub
            </a>
            <a
              className="text-link inline-flex min-h-11 items-center underline decoration-line underline-offset-4 hover:text-bronze hover:decoration-bronze"
              href="https://x.com/sshroud883"
              target="_blank"
              rel="noreferrer"
            >
              X
            </a>
            <a
              className="text-link inline-flex min-h-11 items-center underline decoration-line underline-offset-4 hover:text-bronze hover:decoration-bronze"
              href="https://saberssr114.github.io/KAIZEN/"
              target="_blank"
              rel="noreferrer"
            >
              Kaizen
            </a>
          </p>

          <section id="work" className="rise d6 mt-20">
            <h2 className="text-3xl font-medium tracking-tight">
              The archive, <span className="italic">newest first.</span>
            </h2>
            <p className="mt-3 max-w-prose text-base leading-relaxed text-muted">
              {projects.length} repositories. Live opens the GitHub Pages build when one exists.
              Code opens the repository.
            </p>

            <div className="mt-8">
              <label htmlFor="project-search" className="text-xs tracking-widest text-bronze uppercase">
                Search
              </label>
              <input
                id="project-search"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Name, language, or a word from the note"
                className="mt-2 w-full border-b border-line bg-transparent py-3 text-base text-ink outline-none transition-colors duration-200 placeholder:text-muted focus:border-bronze"
              />
            </div>

            <div className="mt-4 flex flex-wrap gap-1" role="group" aria-label="Filter by language">
              {FILTERS.map((item) => {
                const active = item === filter;
                return (
                  <button
                    key={item}
                    type="button"
                    aria-pressed={active}
                    onClick={() => setFilter(item)}
                    className={
                      "min-h-11 px-3 text-sm underline-offset-4 transition-colors duration-200 " +
                      (active
                        ? "text-ink underline decoration-bronze"
                        : "text-muted hover:text-ink")
                    }
                  >
                    {item}
                  </button>
                );
              })}
            </div>

            <p className="mt-6 text-sm text-muted">
              {visible.length} {visible.length === 1 ? "project" : "projects"}
            </p>

            {visible.length === 0 ? (
              <div className="mt-8 border-t border-line py-10">
                <p className="text-base">Nothing in the archive matches.</p>
                <button
                  type="button"
                  className="mt-3 inline-flex min-h-11 items-center text-sm underline decoration-bronze underline-offset-4"
                  onClick={() => {
                    setQuery("");
                    setFilter("All");
                  }}
                >
                  Show every project
                </button>
              </div>
            ) : (
              <ol key={`${filter}:${query}`} className="mt-2">
                {visible.map((project, index) => (
                  <li
                    key={project.github}
                    className="project-row rise grid grid-cols-[2.25rem_1fr] gap-x-3 border-t border-line py-6 sm:grid-cols-[2.25rem_1fr_7.5rem] sm:gap-x-6"
                    style={{ animationDelay: `${Math.min(index, 12) * 45}ms` }}
                  >
                    <span className="pt-1 text-sm text-muted tabular-nums">
                      {String(index + 1).padStart(2, "0")}
                    </span>
                    <div className="min-w-0">
                      <h3 className="text-xl font-medium tracking-tight">{project.name}</h3>
                      <p className="mt-2 max-w-prose text-sm leading-relaxed text-muted">
                        {project.summary}
                      </p>
                      <p className="mt-3 text-sm text-muted sm:hidden">
                        {project.language ?? "Other"} · {project.pushed}
                        {project.stars > 0 ? ` · ${project.stars} star` : ""}
                      </p>
                      <p className="mt-3 flex flex-wrap gap-x-5">
                        <a
                          href={project.github}
                          target="_blank"
                          rel="noreferrer"
                          className="text-link inline-flex min-h-11 items-center text-sm underline decoration-line underline-offset-4 hover:text-bronze hover:decoration-bronze"
                        >
                          Code
                        </a>
                        {project.live ? (
                          <a
                            href={project.live}
                            target="_blank"
                            rel="noreferrer"
                            className="text-link inline-flex min-h-11 items-center text-sm underline decoration-line underline-offset-4 hover:text-bronze hover:decoration-bronze"
                          >
                            Live
                          </a>
                        ) : null}
                      </p>
                    </div>
                    <div className="hidden text-right text-sm text-muted sm:block">
                      <p>{project.language ?? "Other"}</p>
                      <p className="mt-1">{project.pushed}</p>
                      {project.stars > 0 ? <p className="mt-1">{project.stars} star</p> : null}
                    </div>
                  </li>
                ))}
              </ol>
            )}
          </section>

          <section id="studio" className="rise mt-20 border-t border-line pt-12">
            <h2 className="text-3xl font-medium tracking-tight">
              Studio, <span className="italic">in two halves.</span>
            </h2>
            <div className="mt-6 max-w-prose space-y-4 text-base leading-relaxed">
              <p>
                The GitHub profile is SKIRO. The bio under the name is the same line as the one
                above: good time, good life. Publishing there started in 2025.
              </p>
              <p className="text-muted">
                Kaizen is the artist half — visual work, video editing, design. Its own line is
                Forging Reality From Pixels. The repositories below that are tools, pages, bots,
                and experiments, listed here without dressing them up as more than they are.
              </p>
            </div>
            <p className="mt-6">
              <a
                href="https://saberssr114.github.io/KAIZEN/"
                target="_blank"
                rel="noreferrer"
                className="text-link inline-flex min-h-11 items-center text-sm underline decoration-bronze underline-offset-4 hover:text-bronze"
              >
                Open Kaizen
              </a>
            </p>
          </section>

          <section id="contact" className="rise mt-20 border-t border-line pt-12">
            <h2 className="text-3xl font-medium tracking-tight">
              Contact, <span className="italic">three doors.</span>
            </h2>
            <ul className="mt-6 divide-y divide-line border-y border-line">
              <li>
                <a
                  href="https://github.com/saberssr114"
                  target="_blank"
                  rel="noreferrer"
                  className="door flex min-h-14 items-baseline justify-between gap-4 py-3 hover:text-bronze"
                >
                  <span className="text-lg">GitHub</span>
                  <span className="text-sm text-muted">saberssr114</span>
                </a>
              </li>
              <li>
                <a
                  href="https://x.com/sshroud883"
                  target="_blank"
                  rel="noreferrer"
                  className="door flex min-h-14 items-baseline justify-between gap-4 py-3 hover:text-bronze"
                >
                  <span className="text-lg">X</span>
                  <span className="text-sm text-muted">@sshroud883</span>
                </a>
              </li>
              <li>
                <a
                  href="https://saberssr114.github.io/KAIZEN/"
                  target="_blank"
                  rel="noreferrer"
                  className="door flex min-h-14 items-baseline justify-between gap-4 py-3 hover:text-bronze"
                >
                  <span className="text-lg">Kaizen</span>
                  <span className="text-sm text-muted">Artist site</span>
                </a>
              </li>
            </ul>
          </section>

          <footer className="rise mt-16 flex flex-wrap items-baseline justify-between gap-3 border-t border-line pt-6 text-sm text-muted">
            <p>© 2026 SKIRO</p>
            <a href="#top" className="text-link inline-flex min-h-11 items-center hover:text-bronze">
              Back to the mark
            </a>
          </footer>
        </article>
      </main>
    </div>
  );
}
